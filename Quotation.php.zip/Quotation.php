<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // echo "<pre>";
    // print_r($_POST);
    // exit;

    if (isset($_POST['items']) && !empty($_POST['items'])) {
        $csvFileName = "quotation.csv";
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $csvFileName . '"');

        $output = fopen('php://output', 'w');

        // Add company name at the top
        fputcsv($output, ['AUM AUTOMATION ENGINEERING'], ',', '"', '\\');
        fputcsv($output, [], ',', '"', '\\'); // Empty row for spacing

        // Add headers for CSV file
        fputcsv($output, ['Sr No', 'Item Name', 'Qty', 'GST (%)', 'Price', 'Total Price'], ',', '"', '\\');

        $grandTotal = 0;

        foreach ($_POST['items'] as $index => $item) {
            $srNo = $index + 1;
            $itemName = isset($item['name']) ? htmlspecialchars($item['name']) : 'N/A';
            $qty = isset($item['qty']) ? (int) $item['qty'] : 0;
            $gst = isset($item['gst']) ? (float) $item['gst'] : 18;  // Default GST 18%
            $price = isset($item['price']) ? (float) $item['price'] : 0;
            $totalPrice = $qty * $price * (1 + $gst / 100);

            // Add to grand total
            $grandTotal += $totalPrice;

            // Write row to CSV
            fputcsv($output, [$srNo, $itemName, $qty, $gst, $price, number_format($totalPrice, 2)], ',', '"', '\\');
        }

        fputcsv($output, [], ',', '"', '\\'); // Empty row for spacing

        // Add Grand Total row
        fputcsv($output, ['Grand Total', '', '', '', '', number_format($grandTotal, 2)], ',', '"', '\\');

        fclose($output);
        exit();
    } else {
        echo "No items to process.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quotation Generator - AUM AUTOMATION ENGINEERING</title>
    <script>
        function updatePrice(row) {
            let qty = parseFloat(row.querySelector('.qty').value) || 0;
            let price = parseFloat(row.querySelector('.price').value) || 0;
            let gst = parseFloat(row.querySelector('.gst').value) || 18;
            let total = qty * price * (1 + gst / 100);
            row.querySelector('.total').innerText = total.toFixed(2);
            updateTotalAmount();
        }

        function updateTotalAmount() {
            let totalAmount = 0;
            document.querySelectorAll('.total').forEach(cell => {
                totalAmount += parseFloat(cell.innerText) || 0;
            });
            document.getElementById('grandTotal').innerText = totalAmount.toFixed(2);
        }

        function addRow() {
            let table = document.getElementById('quotationTable').getElementsByTagName('tbody')[0];
            let rowCount = table.rows.length;
            let newRow = table.insertRow(-1);

            newRow.innerHTML = `
                <td>${rowCount + 1}</td>
                <td><input type="text" name="items[${rowCount}][name]" required></td>
                <td><input type="number" class="qty" name="items[${rowCount}][qty]" value="1" onchange="updatePrice(this.parentElement.parentElement)"></td>
                <td><input type="number" class="gst" name="items[${rowCount}][gst]" value="18" onchange="updatePrice(this.parentElement.parentElement)"></td>
                <td><input type="number" class="price" name="items[${rowCount}][price]" value="0" onchange="updatePrice(this.parentElement.parentElement)"></td>
                <td class="total">0.00</td>
                <td><button type="button" onclick="deleteRow(this)">Delete</button></td>
            `;

            updateTotalAmount();
        }

        function deleteRow(button) {
            button.parentElement.parentElement.remove();
            updateTotalAmount();
        }

        document.addEventListener("DOMContentLoaded", function () {
            addRow(); // Add an initial row on page load
        });
    </script>
</head>
<body>
    <h2>AUM AUTOMATION ENGINEERING - Quotation Generator</h2>
    <form method="POST">
        <table id="quotationTable" border="1">
            <thead>
                <tr>
                    <th>Sr No</th>
                    <th>Item Name</th>
                    <th>Qty</th>
                    <th>GST (%)</th>
                    <th>Price</th>
                    <th>Total Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- Rows will be added dynamically here -->
            </tbody>
        </table>
        <button type="button" onclick="addRow()">+ Add Item</button>
        <h3>Total Amount: ₹<span id="grandTotal">0.00</span></h3>
        <button type="submit">Download CSV</button>
    </form>
</body>
</html>
